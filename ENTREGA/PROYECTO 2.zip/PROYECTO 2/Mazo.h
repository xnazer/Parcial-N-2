#ifndef MAZO_H
#define MAZO_H
#include <string>
#include <vector>
#include <iostream>
#include <utility>  
#include "Carta.h"
using namespace std;

class Mazo {
public:
    vector<Carta> cartas;
    Mazo();
    void barajar();
    Carta repartir();
    void mostrar();
};

#endif
