[Project]
FileName=..\Proyecto 2.dev
Name=Proyecto 2
UnitCount=15
Type=1
Ver=1
ObjFiles=
Includes=
Libs=
PrivateResource=
ResourceIncludes=
MakeIncludes=
Compiler=
CppCompiler=
Linker=
IsCpp=1
Icon=
ExeOutput=
ObjectOutput=
OverrideOutput=0
OverrideOutputName=
HostApplication=
Folders=common
CommandLine=
UseCustomMakefile=0
CustomMakefile=
IncludeVersionInfo=0
SupportXPThemes=0
CompilerSet=0
CompilerSettings=

[Unit1]
FileName=.cpp y .h\Batalla.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit2]
FileName=.cpp y .h\Batalla.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit3]
FileName=.cpp y .h\Carta.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit4]
FileName=.cpp y .h\Carta.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit5]
FileName=.cpp y .h\Juego.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit6]
FileName=.cpp y .h\Juego.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit7]
FileName=.cpp y .h\Jugador.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit8]
FileName=.cpp y .h\Jugador.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit9]
FileName=.cpp y .h\Mano.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit10]
FileName=.cpp y .h\Mano.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit11]
FileName=.cpp y .h\Mazo.cpp
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit12]
FileName=.cpp y .h\Mazo.h
CompileCpp=1
Folder=common
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[VersionInfo]
Major=0
Minor=1
Release=1
Build=1
LanguageID=1033
CharsetID=1252
CompanyName=
FileVersion=
FileDescription=Developed using the Dev-C++ IDE
InternalName=
LegalCopyright=
LegalTrademarks=
OriginalFilename=
ProductName=
ProductVersion=
AutoIncBuildNr=0

[Unit13]
FileName=Cliente .cpp
CompileCpp=1
Folder=Proyecto 2
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit15]
FileName=main.cpp
CompileCpp=1
Folder=Proyecto 2
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

[Unit14]
FileName=Servidor.cpp
CompileCpp=1
Folder=Proyecto 2
Compile=1
Link=1
Priority=1000
OverrideBuildCmd=0
BuildCmd=

