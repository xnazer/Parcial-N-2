#include "Juego.h"
#include <winsock2.h> 
#include <iostream>

using namespace std;

Juego::Juego(int n) {
    this->numJugadores = n;
    int cartasPorJugador = 36 / n;
    for (int i = 0; i < n; i++) {
        jugadores.push_back(Jugador(i + 1, cartasPorJugador, this->mazo.cartas));
    }
}


void Juego::jugar() {

    for (int ronda = 0; ronda < 18; ronda++) { 
        cout << "\n--- Ronda " << ronda + 1 << " ---\n";
        btla.iniciarRonda();
        for (Jugador &j : jugadores) {
            j.mostrarMano();
            int eleccion;
            do {
                cout << "Jugador " << j.id << ", elige una carta para lanzar (1 - " << j.mano.cartas.size() << "): ";
                cin >> eleccion;
            } while (eleccion < 1 || eleccion > j.mano.cartas.size());

            Carta lanzada = j.mano.lanzar(eleccion - 1);
            cout << "Jugador " << j.id << " lanza: "; lanzada.mostrar(); cout << endl;
            btla.comparar(j, lanzada);
        }
        Jugador* ganadorRonda = btla.definirGanadorRonda();
        if (ganadorRonda) {
            cout << "Ganador de la ronda: Jugador " << ganadorRonda->id << "\n";
            for (auto &entrada : btla.cartasLanzadas) {
                ganadorRonda->almacenarCarta(entrada.second);
            }
        } else {
            cout << "Nadie gan� la ronda, las cartas quedan descartadas.\n";
        }

        bool cartasDisponibles = false;
        for (Jugador &j : jugadores) {
            if (!j.mano.cartas.empty()) {
                cartasDisponibles = true;
                break;
            }
        }
        if (!cartasDisponibles) {
            cout << "\nLas cartas se han agotado. Fin del juego.\n";
            break;
        }
    }

    determinarGanador();
}

void Juego::determinarGanador() {
    for (Jugador &j : jugadores) {
        j.mostrarBoveda();
    }
    Jugador *ganador = &jugadores[0];
    for (Jugador &j : jugadores) {
        if (j.contarCartasBoveda() > ganador->contarCartasBoveda()) {
            ganador = &j;
        }
    }
    cout << "\nEl ganador final es el Jugador " << ganador->id << " con " << ganador->contarCartasBoveda() << " cartas en la bodega!\n";
}


int Juego::jugarRondaMultijugador(const std::vector<int>& elecciones) {
    btla.iniciarRonda();

    for (size_t i = 0; i < elecciones.size(); ++i) {
        Jugador& jugadorActual = jugadores[i]; 
        int eleccion = elecciones[i]; 

        if (eleccion >= 1 && eleccion <= jugadorActual.mano.cartas.size()) {
            Carta lanzada = jugadorActual.mano.lanzar(eleccion - 1);
            btla.comparar(jugadorActual, lanzada);
        } else {

            cout << "Jugador " << jugadorActual.id << " no jug� una carta v�lida esta ronda." << endl;
        }
    }

    Jugador* ganadorRonda = btla.definirGanadorRonda();

    if (ganadorRonda) {

        for (auto &entrada : btla.cartasLanzadas) {
            ganadorRonda->almacenarCarta(entrada.second);
        }
        return ganadorRonda->id; 
    } else {
       
        cout << "Nadie gan� la ronda, las cartas quedan descartadas.\n";
        return 0; 
    }
}

bool Juego::finDeJuego() const {
    static int rondasJugadas = 0; 
    rondasJugadas++;

    return rondasJugadas >= 18;
}
