#ifndef MANO_H
#define MANO_H
#include <string>
#include <vector>
#include <iostream>
#include <utility>  
#include "Carta.h"
using namespace std;

class Mano {
public:
    vector<Carta> cartas;
    Mano() {}
    Mano(int cantidad, vector<Carta>& mazo);
    void mostrar();
    Carta lanzar(int ncartas);
};

#endif
