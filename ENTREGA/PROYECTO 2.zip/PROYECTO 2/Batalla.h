#ifndef BATALLA_H
#define BATALLA_H

#include <string>
#include <vector>
#include <iostream>
#include <utility>
#include "Carta.h"
#include "Jugador.h"

using namespace std;

class Batalla {
public:
    int colorInicial = -1;
    vector<pair<Jugador*, Carta>> cartasLanzadas;
    bool primeraCarta = true;

    void iniciarRonda();
    void comparar(Jugador& jugador, Carta carta);
    Jugador* definirGanadorRonda();
};

#endif
