#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <vector>
#include <thread>
#include "Juego.h"
#include <ctime> 

#define PUERTO 8080
#define MAX_JUGADORES 4

void handleGame(std::vector<SOCKET>& clientes) {
    int numJug = clientes.size();

    srand(time(NULL));

    Juego juego(numJug);

    for (int i = 0; i < numJug; ++i) {
        int id = i + 1;
        send(clientes[i], (char*)&id, sizeof(id), 0);
    }

    int cmdInitialUpdate = 2;
    for (auto s : clientes) {
        send(s, (char*)&cmdInitialUpdate, sizeof(cmdInitialUpdate), 0);
    }
    int initialRound = 0;
    int initialNumCardsPlayed = 0;
    for (auto s : clientes) {
        send(s, (char*)&initialRound, sizeof(initialRound), 0);
        send(s, (char*)&initialNumCardsPlayed, sizeof(initialNumCardsPlayed), 0);
    }
    int numPlayers = juego.jugadores.size();
    for (auto s : clientes) {
        send(s, (char*)&numPlayers, sizeof(numPlayers), 0); 
    }
    for (const auto& jug : juego.jugadores) { 
        int playerId = jug.id;
        int cardsInVault = jug.contarCartasBoveda();
        for (auto s : clientes) {
            send(s, (char*)&playerId, sizeof(playerId), 0);
            send(s, (char*)&cardsInVault, sizeof(cardsInVault), 0);
        }
    }

    int currentRound = 0;
    while (true) {
        currentRound++;
        std::cout << "\n--- Ronda " << currentRound << " ---\n";

        bool cardsAvailable = false;
        for (int i = 0; i < numJug; ++i) {
            if (!juego.jugadores[i].mano.cartas.empty()) {
                cardsAvailable = true;
                break;
            }
        }
        if (!cardsAvailable) {
            std::cout << "Fin del juego: Todos los jugadores se han quedado sin cartas.\n";
            break;
        }

        std::vector<int> elecciones(numJug);
        for (int i = 0; i < numJug; ++i) {
            if (!juego.jugadores[i].mano.cartas.empty()) {
                int cmd = 1;
                send(clientes[i], (char*)&cmd, sizeof(cmd), 0);

                int numCardsInHand = juego.jugadores[i].mano.cartas.size();
                send(clientes[i], (char*)&numCardsInHand, sizeof(numCardsInHand), 0);
                for (const auto& card : juego.jugadores[i].mano.cartas) {
                    send(clientes[i], (char*)&card.poder, sizeof(card.poder), 0);
                    send(clientes[i], (char*)&card.color, sizeof(card.color), 0);
                }

                recv(clientes[i], (char*)&elecciones[i], sizeof(elecciones[i]), 0);
                std::cout << "Jugador " << juego.jugadores[i].id << " eligi� carta " << elecciones[i] << "\n";
            } else {
                elecciones[i] = 0;
                std::cout << "Jugador " << juego.jugadores[i].id << " no tiene cartas para jugar.\n";
            }
        }

        int ganadorID = juego.jugarRondaMultijugador(elecciones);

        for (auto s : clientes) {
            send(s, (char*)&ganadorID, sizeof(ganadorID), 0);
        }

        int cmdUpdate = 2;
        for (auto s : clientes) {
            send(s, (char*)&cmdUpdate, sizeof(cmdUpdate), 0);
        }

        for (auto s : clientes) {
            send(s, (char*)&currentRound, sizeof(currentRound), 0);
        }

        int numCardsPlayedInRound = juego.btla.cartasLanzadas.size();
        for (auto s : clientes) {
            send(s, (char*)&numCardsPlayedInRound, sizeof(numCardsPlayedInRound), 0);
        }
        
        for (auto const& entry : juego.btla.cartasLanzadas) {
            int playerId = entry.first->id; 
            int cardPower = entry.second.poder;
            int cardColor = entry.second.color;
            for (auto s : clientes) {
                send(s, (char*)&playerId, sizeof(playerId), 0);
                send(s, (char*)&cardPower, sizeof(cardPower), 0);
                send(s, (char*)&cardColor, sizeof(cardColor), 0);
            }
        }

        numPlayers = juego.jugadores.size();
        for (auto s : clientes) {
            send(s, (char*)&numPlayers, sizeof(numPlayers), 0);
        }
        for (const auto& jug : juego.jugadores) {
            int playerId = jug.id;
            int cardsInVault = jug.contarCartasBoveda();
            for (auto s : clientes) {
                send(s, (char*)&playerId, sizeof(playerId), 0);
                send(s, (char*)&cardsInVault, sizeof(cardsInVault), 0);
            }
        }

        if (juego.finDeJuego()) {
            std::cout << "Fin del juego: Rondas completadas.\n";
            break;
        }
    }

    juego.determinarGanador();

    int endCmd = 0;
    for (auto s : clientes) {
        send(s, (char*)&endCmd, sizeof(endCmd), 0);
    }
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
        std::cerr << "Error al inicializar Winsock" << std::endl;
        return 1;
    }

    SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener == INVALID_SOCKET) {
        std::cerr << "Error al crear el socket de escucha: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PUERTO);

    if (bind(listener, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        std::cerr << "Error al vincular el socket: " << WSAGetLastError() << std::endl;
        closesocket(listener);
        WSACleanup();
        return 1;
    }

    if (listen(listener, MAX_JUGADORES) == SOCKET_ERROR) {
        std::cerr << "Error al escuchar conexiones: " << WSAGetLastError() << std::endl;
        closesocket(listener);
        WSACleanup();
        return 1;
    }
    std::cout << "Servidor escuchando en puerto " << PUERTO << "\n";

    int nJug;
    do {
        std::cout << "Ingrese el numero de jugadores (2-" << MAX_JUGADORES << "): ";
        std::cin >> nJug;
    } while (nJug < 2 || nJug > MAX_JUGADORES);

    std::vector<SOCKET> clientes;
    while ((int)clientes.size() < nJug) {
        std::cout << "Esperando jugador " << clientes.size() + 1 << "...\n";
        SOCKET c = accept(listener, nullptr, nullptr);
        if (c != INVALID_SOCKET) {
            std::cout << "Jugador conectado (#" << clientes.size()+1 << ")\n";
            clientes.back().push_back(c);
        } else {
            std::cerr << "Error al aceptar conexi�n: " << WSAGetLastError() << std::endl;
        }
    }
    std::cout << "Todos los jugadores conectados. Iniciando partida...\n";

    handleGame(clientes);

    for (auto s : clientes) closesocket(s);
    closesocket(listener);
    WSACleanup();
    return 0;
}
