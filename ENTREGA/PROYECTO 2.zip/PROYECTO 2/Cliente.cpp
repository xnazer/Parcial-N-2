#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include "Mano.h"
#define PUERTO 8080

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
        std::cerr << "Error al inicializar Winsock" << std::endl;
        return 1;
    }

    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) {
        std::cerr << "Error al crear el socket: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    std::string ip;
    std::cout << "IP del servidor: ";
    std::cin >> ip;

    sockaddr_in srv = {};
    srv.sin_family = AF_INET;
    srv.sin_port = htons(PUERTO);
    if (inet_pton(AF_INET, ip.c_str(), &(srv.sin_addr)) <= 0) { 
        std::cerr << "IP Invalida" << std::endl;
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    if (connect(sock, (sockaddr*)&srv, sizeof(srv)) != 0) {
        std::cerr << "Error al conectar con el servidor: " << WSAGetLastError() << std::endl;
        closesocket(sock);
        WSACleanup();
        return 1;
    }
    std::cout << "Conectado al servidor\n";

    int miID;
    recv(sock, (char*)&miID, sizeof(miID), 0);
    std::cout << "Tu ID de jugador: " << miID << "\n";

    while (true) {
        int cmd;
        int bytesReceived = recv(sock, (char*)&cmd, sizeof(cmd), 0);
        if (bytesReceived <= 0) {
            std::cerr << "Conexion perdida con el servidor o fin de datos." << std::endl;
            break;
        }

        if (cmd == 0) {
            std::cout << "Fin del juego. Desconectando...\n";
            break;
        }
        else if (cmd == 1) {
            std::cout << "\n--- Es tu turno, Jugador " << miID << " --- \n";
            std::cout << "Elige una carta para lanzar (ej. 1, 2, 3): ";
            int ele;
            std::cin >> ele;
            send(sock, (char*)&ele, sizeof(ele), 0);

            int ganador;
            recv(sock, (char*)&ganador, sizeof(ganador), 0);
            if (ganador != 0) {
                 std::cout << "Ganador de la ronda: Jugador " << ganador << "\n";
            } else {
                std::cout << "Nadie gan� esta ronda.\n";
            }
        }
        else if (cmd == 2) {
            std::cout << "\n--- Estado Actual del Juego ---\n";

            int receivedRound;
            recv(sock, (char*)&receivedRound, sizeof(receivedRound), 0);
            std::cout << "Ronda actual: " << receivedRound << "\n";

            int receivedNumCardsPlayed;
            recv(sock, (char*)&receivedNumCardsPlayed, sizeof(receivedNumCardsPlayed), 0);
            std::cout << "Cartas jugadas en esta ronda:\n";
            if (receivedNumCardsPlayed == 0 && receivedRound == 0) { 
                std::cout << "  (Comenzando partida, ninguna carta jugada aun)\n";
            } else if (receivedNumCardsPlayed == 0 && receivedRound > 0) {
                 std::cout << "  (Ninguna carta jugada en esta ronda)\n";
            } else {
                for (int i = 0; i < receivedNumCardsPlayed; ++i) {
                    int playerId;
                    int cardPower;
                    int cardColor;
                    recv(sock, (char*)&playerId, sizeof(playerId), 0);
                    recv(sock, (char*)&cardPower, sizeof(cardPower), 0);
                    recv(sock, (char*)&cardColor, sizeof(cardColor), 0);
                    Carta playedCard(cardPower, cardColor);
                    std::cout << "  Jugador " << playerId << " jug�: ";
                    playedCard.mostrar();
                    std::cout << "\n";
                }
            }

            int receivedNumPlayers;
            recv(sock, (char*)&receivedNumPlayers, sizeof(receivedNumPlayers), 0);
            std::cout << "Cartas en la b�veda de los jugadores:\n";
            for (int i = 0; i < receivedNumPlayers; ++i) {
                int playerId;
                int cardsInVault;
                recv(sock, (char*)&playerId, sizeof(playerId), 0);
                recv(sock, (char*)&cardsInVault, sizeof(cardsInVault), 0);
                std::cout << "  Jugador " << playerId << ": " << cardsInVault << " cartas\n";
            }
            std::cout << "----------------------------------\n";
        }
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}
