#ifndef JUGADOR_H
#define JUGADOR_H

#include <string>
#include <vector>
#include <iostream>
#include <utility>
#include "Mano.h"
#include "Carta.h"

using namespace std;

class Jugador {
public:
    int id;
    Mano mano;
    vector<Carta> boveda;

    Jugador(int i, int cantidadCartas, vector<Carta>& mazo);
    void mostrarMano();
    void almacenarCarta(Carta c);
    int contarCartasBoveda();
    void mostrarBoveda();
};

#endif
