#ifndef JUEGO_H
#define JUEGO_H

#include <string>
#include <vector>
#include <iostream>
#include <winsock2.h> // Keep this for PUERTO and MAX_CLIENTES if still needed, though Servidor.cpp defines it.
#include <utility>
#include "Mazo.h"
#include "Batalla.h"

using namespace std;

class Juego {
public:
    vector<Jugador> jugadores;
    Batalla btla;
    Mazo mazo; // This will be initialized by its default constructor
    int numJugadores;
    // int jugadorActual; // Not directly used for turn management in current multiplayer model
    // int PUERTO = 12345; // Server defines this
    // int MAX_CLIENTES = 4; // Server defines this

    Juego(int n);
    void jugar(); // For local game, not directly used by current multiplayer logic
    void determinarGanador();
    // void iniciarPartidaMultijugador(vector<SOCKET>& clientes); // Removed as server responsibility
    // void unirseAPartidaMultijugador(SOCKET sock, int idJugador); // Removed as client responsibility

    // New function to process a multiplayer round using Batalla logic
    int jugarRondaMultijugador(const std::vector<int>& elecciones);
    bool finDeJuego() const; // <--- ADDED 'const' HERE

private:
    // bool validarTurno(int idJugador); // Not directly used
    // void mostrarEstado(); // Not directly used
    // void procesarResultadosRonda(); // Replaced by logic in jugarRondaMultijugador
};

#endif
