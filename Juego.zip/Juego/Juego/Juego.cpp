#include "Juego.h"
#include <iostream>

using namespace std;

Juego::Juego(int n) {
    
    this->numJugadores = n;
    this->mazo = mazo;
    int cartasPorJugador = 36 / n;
    for (int i = 0; i < n; i++) jugadores.push_back(Jugador(i + 1, cartasPorJugador, mazo.cartas));
    
}

void Juego::jugar() {
    
    for (int ronda = 0; ronda < 18; ronda++) {
        cout << "\n--- Ronda " << ronda + 1 << " ---\n";
        btla.iniciarRonda();
        for (Jugador &j : jugadores) {
            j.mostrarMano();
            int eleccion;
            do {
                cout << "Jugador " << j.id << ", elige una carta para lanzar (1 - " << j.mano.cartas.size() << "): ";
                cin >> eleccion;
            } while (eleccion < 1 || eleccion > j.mano.cartas.size());
            
            Carta lanzada = j.mano.lanzar(eleccion - 1);
            cout << "Jugador " << j.id << " lanza: "; lanzada.mostrar(); cout << endl;
            btla.comparar(j, lanzada);
        }
        Jugador* ganadorRonda = btla.definirGanadorRonda();
        if (ganadorRonda) {
            cout << "Ganador de la ronda: Jugador " << ganadorRonda->id << "\n";
            for (auto &entrada : btla.cartasLanzadas) {
                ganadorRonda->almacenarCarta(entrada.second);
            }
        } else {
            cout << "Nadie ganó la ronda, las cartas quedan descartadas.\n";
        }
         bool cartasDisponibles = false;
    for (Jugador &j : jugadores) {
        if (!j.mano.cartas.empty()) {
            cartasDisponibles = true;
            break;
        }
    }
    if (!cartasDisponibles) {
        cout << "\nLas cartas se han agotado. Fin del juego.\n";
        break;
    }
    }
    
    determinarGanador();
}

void Juego::determinarGanador() {
    for (Jugador &j : jugadores) {
        j.mostrarBoveda();
    }
    Jugador *ganador = &jugadores[0];
    for (Jugador &j : jugadores) {
        if (j.contarCartasBoveda() > ganador->contarCartasBoveda()) {
            ganador = &j;
        }
    }
    cout << "\nEl ganador final es el Jugador " << ganador->id << " con " << ganador->contarCartasBoveda() << " cartas en la bodega!\n";
}