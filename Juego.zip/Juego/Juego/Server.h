
#ifndef SERVER_H
#define SERVER_H

#include <ENet/ENet.h>
#include "Batalla.h"
#include <vector>

class Server {
private:
    ENetHost* server;
    std::vector<ENetPeer*> clientes;
    Batalla batalla;
    bool running;

public:
    Server();
    ~Server();
    
    bool iniciar(int puerto = 4242);
    void ejecutar();
    void detener();
    
private:
    void manejarNuevaConexion(ENetPeer* peer);
    void manejarDesconexion(ENetPeer* peer);
    void procesarMensaje(ENetPacket* packet, ENetPeer* remitente);
    void actualizarEstadoJuego();
    void enviarEstadoInicial(ENetPeer* peer);
    void enviarActualizacionesATodos();
    void procesarLanzamientoCarta(Mensaje mensaje, ENetPeer* remitente);
};

#endif // SERVER_H