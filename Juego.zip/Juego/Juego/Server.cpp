#include <ENet/ENet.h>
#include "Batalla.h"
#include <vector>

class Servidor {
private:
    ENetAddress address;
    ENetHost* server;
    std::vector<ENetPeer*> clientes;
    Batalla batalla;

public:
    bool iniciar(int puerto = 4242) {
        if (enet_initialize() != 0) {
            return false;
        }

        server = enet_host_create(NULL, 64, 2, 49152, 3);
        if (!server) {
            enet_deinitialize();
            return false;
        }

        enet_address_set_host(&address, "localhost");
        address.port = puerto;

        return true;
    }

    void ejecutarBuclePrincipal() {
        ENetEvent event;
        int timeout = 100; // 100ms para mantener el juego fluido

        while (true) {
            while (enet_host_service(server, &event, timeout) > 0) {
                switch (event.type) {
                    case ENET_EVENT_TYPE_CONNECT:
                        manejarNuevaConexion(event.peer);
                        break;
                    case ENET_EVENT_TYPE_DISCONNECT:
                        manejarDesconexion(event.peer);
                        break;
                    case ENET_EVENT_TYPE_RECEIVE:
                        procesarMensaje(event.packet, event.peer);
                        enet_packet_destroy(event.packet);
                        break;
                }
            }

            actualizarEstadoJuego();
        }
    }

private:
    void manejarNuevaConexion(ENetPeer* peer) {
        clientes.push_back(peer);
        enviarEstadoInicial(peer);
    }

    void manejarDesconexion(ENetPeer* peer) {
        auto it = std::find(clientes.begin(), clientes.end(), peer);
        if (it != clientes.end()) {
            clientes.erase(it);
        }
    }

    void procesarMensaje(ENetPacket* packet, ENetPeer* remitente) {
        Mensaje mensaje;
        memcpy(&mensaje, packet->data, sizeof(Mensaje));

        switch (mensaje.tipo) {
            case TIPO_LANZAR_CARTA:
                procesarLanzamientoCarta(mensaje, remitente);
                break;
            // Otros tipos de mensajes...
        }
    }

    void actualizarEstadoJuego() {
        batalla.actualizar();
        enviarActualizacionesATodos();
    }
};