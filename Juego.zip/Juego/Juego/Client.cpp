// Client.cpp
#include "Client.h"
#include <ENet/ENet.h>
#include <iostream>

Client::Client() : client(nullptr), running(false) {}

Client::~Client() {
    if (client) {
        enet_host_destroy(client);
    }
    enet_deinitialize();
}

bool Client::conectar(const char* direccionServidor, int puerto) {
    if (enet_initialize() != 0) {
        std::cerr << "Error al inicializar ENet" << std::endl;
        return false;
    }

    client = enet_host_create(nullptr, 1, 2, 49152, 3);
    if (!client) {
        std::cerr << "Error al crear el cliente" << std::endl;
        enet_deinitialize();
        return false;
    }

    ENetAddress address;
    enet_address_set_host(&address, direccionServidor);
    address.port = puerto;

    ENetPeer* peer = enet_host_connect(client, &address, 2, 0);
    if (!peer) {
        std::cerr << "Error al conectar al servidor" << std::endl;
        enet_host_destroy(client);
        enet_deinitialize();
        return false;
    }

    running = true;
    return true;
}

void Client::actualizar() {
    if (!running) return;

    ENetEvent event;
    int timeout = 100;

    while (enet_host_service(client, &event, timeout) > 0) {
        switch (event.type) {
            case ENET_EVENT_TYPE_RECEIVE:
                procesarMensaje(event.packet);
                enet_packet_destroy(event.packet);
                break;
        }
    }

    batallaLocal.actualizar();
}

void Client::procesarMensaje(ENetPacket* packet) {
    Mensaje mensaje;
    memcpy(&mensaje, packet->data, sizeof(Mensaje));

    switch (mensaje.tipo) {
        case TIPO_ACTUALIZAR_ESTADO:
            actualizarEstadoJuego(mensaje);
            break;
    }
}

void Client::actualizarEstadoJuego(Mensaje mensaje) {
    batallaLocal.actualizarDesdeServidor(mensaje.estado);
}

void Client::detener() {
    running = false;
}