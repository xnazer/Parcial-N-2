
#ifndef CLIENT_H
#define CLIENT_H

#include <ENet/ENet.h>
#include "Batalla.h"

class Client {
private:
    ENetHost* client;
    Batalla batallaLocal;
    bool running;

public:
    Client();
    ~Client();
    
    bool conectar(const char* direccionServidor, int puerto);
    void actualizar();
    void detener();
    
private:
    void procesarMensaje(ENetPacket* packet);
    void actualizarEstadoJuego(Mensaje mensaje);
};

#endif // CLIENT_H