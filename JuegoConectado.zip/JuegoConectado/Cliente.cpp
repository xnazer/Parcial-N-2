#include "Juego.h"
#include <winsock2.h>
#include <ws2tcpip.h>

#define PUERTO 54000

using namespace std;

int main() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    
    string ipServidor;
    cout << "Ingrese la IP del servidor: ";
    cin >> ipServidor;

    sockaddr_in hint;
    hint.sin_family = AF_INET;
    hint.sin_port = htons(PUERTO);
    inet_pton(AF_INET, ipServidor.c_str(), &hint.sin_addr);

    if (connect(sock, (sockaddr*)&hint, sizeof(hint)) == SOCKET_ERROR) {
        cerr << "Error al conectar con el servidor." << endl;
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    cout << "Conectado al servidor!" << endl;

    // Recibir ID del jugador
    int miID;
    recv(sock, (char*)&miID, sizeof(miID), 0);

    Juego juego(1); // Solo un jugador en el cliente
    juego.unirseAPartidaMultijugador(sock, miID);

    closesocket(sock);
    WSACleanup();
    return 0;
}
